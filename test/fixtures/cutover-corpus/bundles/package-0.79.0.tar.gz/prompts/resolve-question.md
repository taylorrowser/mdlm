---
id: resolve-question
version: 2
scenario: resolve-question
---

# Resolve a question

Read, in order:

1. `skills/lifecycle-data.md@1`
2. `skills/clarification-protocol.md@1`
3. `skills/traceability.md@1`

Work from one exact open QST revision. Preferential questions require an explicit
stakeholder answer and explicit `stakeholder` execution authority; empirical
questions require cited evidence sufficient for the claim. If the needed answer is unavailable, defer only with a concrete
reactivation condition and blocking impact. Cancellation must be intentional and
reasoned.

For a consequential answer, any deferral, or any cancellation, create one DEC
with one `resolves` link to the emitted current QST revision. Do not link or
claim to resolve the historical input QST; it is supplied only to author the
next Revision and may be absent from the DEC's frozen Review Context. Normalize
an attended product answer into one self-contained `attended_answer` on the
answered QST.
Keep the supplied behavior, boundaries, and constraints. Do not store a chat
transcript. Copy that normalized answer exactly into the initial DEC `decision`.
A routine autonomous empirical answer may publish only the next QST Revision and its cited evidence;
do not manufacture a DEC merely to repeat the answer. Always create the next
QST revision with state `answered`, `deferred`, or `cancelled`. Preserve the
input QST's exact `kind`, `intent_scope`, question text, and complete `blocks`
link set so the reviewed answer retains its exact affected foundation scope. An initial
`intent_scope: product` Question must be answered, not deferred or cancelled,
and its normalized attended answer must be self-contained.
Do not rewrite the old question. Record alternatives and effective scope when material.
A deferral is not an answer, and uncertainty must remain visible.

Validate both outputs and record exact provenance. The DEC is reviewed when the
resolved review policy marks it consequential.

Before proposing authored Lifecycle Data, apply the bounded ephemeral
`skills/author-preflight.md@2` contract.
