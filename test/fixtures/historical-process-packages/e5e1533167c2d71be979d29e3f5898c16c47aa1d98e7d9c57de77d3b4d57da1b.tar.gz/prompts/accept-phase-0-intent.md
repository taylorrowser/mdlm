---
id: accept-phase-0-intent
version: 1
scenario: accept-phase-0-intent
---

# Accept the exact Phase 0 intent

Read `skills/lifecycle-data.md@1`, `skills/baseline-model.md@1`, and
`skills/gate-protocol.md@1`. Create one frozen `intent-approved` BSL with role
`accepted`, the exact candidate definition members, and the supplied candidate
simplification Review, approving gate DEC, and gate-Decision Review as evidence.
Link `promotes` to the exact candidate and preserve scope and group exactly. This
is mechanical publication of already reviewed authorization; do not request or
invent another stakeholder decision.

Before proposing authored Lifecycle Data, apply the bounded ephemeral
`skills/author-preflight.md@2` contract.
