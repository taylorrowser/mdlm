---
id: revise-pilot-vai-after-review
version: 1
scenario: revise-pilot-vai-after-review
skills: [skills/lifecycle-data.md@1, skills/verification-activity-implementation.md@1, skills/verification-independence.md@1, skills/reproducibility.md@1, skills/verification-run-model.md@1, skills/author-preflight.md@2]
---

# Correct one failed source-blind pilot procedure

Create the next Revision in the supplied VAI lineage. Cite and address every
supplied failed Review, preserving the exact pilot claim class, declared cases,
VER, ENV, ART, supported behavior, and intentionally unsupported behavior. The
replacement may revise procedure and activity-binding text when needed to address
an exact failed Review Finding. Do not mutate or reuse the failed VAI, Reviews,
or prior RUN/RES evidence.

Give checkout, environment checks, and each product case positive bounded
infrastructure-safety deadlines. On timeout, terminate the process group with
SIGTERM then SIGKILL after a bounded grace period, reap all descendants, retain
partial raw stdout/stderr observations, guarantee cleanup, and continue through
all remaining cases before aggregation.

Publish one exact `authorization` DEC with `effective_scope` equal to
`$proposal.<replacement-local-id>.revision_id` and a `justifies` link to the
replacement. Use `kind: decision` for autonomous participation and `kind: scope`
for attended participation.

Before proposing authored Lifecycle Data, apply the bounded ephemeral
`skills/author-preflight.md@2` contract.
